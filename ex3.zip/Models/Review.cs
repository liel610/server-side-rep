﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ArticleProject.Models.DAL;

namespace Reviewproj.Models
{
    public class Review
    {
        string articleId;
        string criticizerName;
        string email;
        string date;
        int rank;
        string criticize;

        public Review()
        {
        }

        public Review(string articleId, string criticizerName, string email, string date, int rank, string criticize)
        {
            this.articleId = articleId;
            this.criticizerName = criticizerName;
            this.email = email;
            this.date = date;
            this.rank = rank;
            this.criticize = criticize;
        }
        
        public string ArticleId { get => articleId; set => articleId = value; }
        public string CriticizerName { get => criticizerName; set => criticizerName = value; }
        public string Email { get => email; set => email = value; }
        public string Date { get => date; set => date = value; }
        public int Rank { get => rank; set => rank = value; }
        public string Criticize { get => criticize; set => criticize = value; }


        public int Insert()
        {
            DataServices ds = new DataServices();
            return ds.Insert(this);
        }

        public List<Review> Read()
        {
            DataServices ds = new DataServices();
            return ds.Read(12);
        }
    }
}