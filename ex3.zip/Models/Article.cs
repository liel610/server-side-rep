﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using ArticleProject.Models.DAL;
namespace ArticleProject.Models
{
    public class Article
    {
        string tVid;
        string tVname;
        string articleTitle;
        string articleShortcut;
        string articleOrigin;
        string dateOfPublish;
        string articleImage;
        string linkToArticle;
        string articleId;

        public Article() { }//empty constructor

        //full constructor
        public Article(string tVid, string tVname, string articleTitle, string articleShortcut, string articleOrigin, string dateOfPublish, string articleImage, string linkToArticle,string articleId)
        {
            this.tVid = tVid;
            this.tVname = tVname;
            this.articleTitle = articleTitle;
            this.articleShortcut = articleShortcut;
            this.articleOrigin = articleOrigin;
            this.dateOfPublish = dateOfPublish;
            this.articleImage = articleImage;
            this.linkToArticle = linkToArticle;
            this.articleId = articleId;
        }

        //properties
        public string TVid { get => tVid; set => tVid = value; }
        public string TVname { get => tVname; set => tVname = value; }
        public string ArticleTitle { get => articleTitle; set => articleTitle = value; }
        public string ArticleShortcut { get => articleShortcut; set => articleShortcut = value; }
        public string ArticleOrigin { get => articleOrigin; set => articleOrigin = value; }
        public string DateOfPublish { get => dateOfPublish; set => dateOfPublish = value; }
        public string ArticleImage { get => articleImage; set => articleImage = value; }
        public string LinkToArticle { get => linkToArticle; set => linkToArticle = value; }
        public string ArticleId { get => articleId; set => articleId = value; }

        public List<string> Read()
        {
            DataServices ds = new DataServices();
            return ds.Read();
        }

        public List<Article> Read(string tvname)
        {
            DataServices ds = new DataServices();
            return ds.Read(tvname);
        }

        public int Insert()
        {
            DataServices ds = new DataServices();
            return ds.Insert(this);
        }

    }
}