﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Reviewproj.Models;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace ArticleProject.Models.DAL
{
    public class DataServices
    {
        static List<Article> ArticleList;
        static List<Review> ReviewList;
        public List<string> Read()//פונקציית קריאה 
        {
            List<string> uniqArticle = new List<string>();
            foreach (var item in ArticleList)
            {
                
                if (uniqArticle.Contains(item.TVname) ==false)
                {
                    uniqArticle.Add(item.TVname);
                }
            }
            return uniqArticle;
        }
        public List<Review> Read(int num)//פונקציית קריאה 
        {
            return ReviewList;
        }

        public List<Article> Read(string tvname)//פונקציית קריאה 
        {
            List<Article> speclist = new List<Article>();

            foreach (Article a in ArticleList)
            {

                if (a.TVname== tvname)
                {
                    speclist.Add(a);
                }
            }
            return speclist;
        }

        public static string Filter(string str, List<char> charsToRemove)
        {
            foreach (char c in charsToRemove)
            {
                str = str.Replace(c.ToString(), String.Empty);
            }

            return str;
        }

        public int Insert(Article article)
        {
            //עבודה עם רשימה למחוק !!!!!!!
            if (ArticleList == null)
            {
                ArticleList = new List<Article>();
            }
            ArticleList.Add(article);
            /////////////////

            SqlConnection con = null;
            int numEffected = 0;

            List<char> charsToRemove = new List<char>() { '\'', '"' };
            article.ArticleTitle = Filter(article.ArticleTitle , charsToRemove);
            article.ArticleShortcut = Filter(article.ArticleShortcut, charsToRemove);
            article.ArticleOrigin = Filter(article.ArticleOrigin, charsToRemove);


            try
            {
                    //C - Connect to the Database
                    con = Connect("imdbProjDB");

                    //C Create the Insert SqlCommand
                    SqlCommand insertCommand = CreateInsertCommand(article, con);

                    //E Execute
                    numEffected = insertCommand.ExecuteNonQuery();

                }

                catch (Exception ex)
                {
                    // this code needs to write the error to a log file
                    throw new Exception("Failed to insert a article", ex);


                }

                finally
                {
                    //C Close Connction
                    con.Close();
                }



                // num effected
                return numEffected;

        }


        SqlCommand CreateInsertCommand(Article article, SqlConnection con)
        {
            
            //INSERT INTO students_2022 ([name],age) values ('benny',56)
            string sqlString = "INSERT INTO Articles_2022 (tVid,tVname,articleTitle,articleShortcut,articleOrigin,dateOfPublish,articleImage,linkToArticle,articleId) " + "VALUES ('" + article.TVid+ "','" + article.TVname + "','" + article.ArticleTitle + "','" + article.ArticleShortcut+ "','" + article.ArticleOrigin + "','" + article.DateOfPublish + "','" + article.ArticleImage + "','" + article.LinkToArticle + "','" + article.ArticleId + "')";
            SqlCommand command = new SqlCommand(sqlString, con);
            command.CommandTimeout = 5; // after 5 secoend it will return a timeout exception
            command.CommandType = System.Data.CommandType.Text;
            return command;
        }

        // Open a new connection to the database
        SqlConnection Connect(string connectionStringName)
        {

            string connectionString = WebConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            return con;

        }
        public int Insert(Review r)
        {
            //עבודה עם רשימה למחוק !!!!!!!
            if (ReviewList == null)
            {
                ReviewList = new List<Review>();
            }
            ReviewList.Add(r);
            ////////////////////////

            SqlConnection con = null;
                int numEffected = 0;

                

                try
                {
                    //C - Connect to the Database
                    con = Connect("imdbProjDB");

                    //C Create the Insert SqlCommand
                    SqlCommand insertCommand = CreateInsertCommand(r, con);

                    //E Execute
                    numEffected = insertCommand.ExecuteNonQuery();

                }

                catch (Exception ex)
                {
                    // this code needs to write the error to a log file
                    throw new Exception("Failed to insert a Review", ex);


                }

                finally
                {
                    //C Close Connction
                    con.Close();
                }



                // num effected
                return numEffected;

        }
        SqlCommand CreateInsertCommand(Review review, SqlConnection con)
        {
       
            //INSERT INTO students_2022 ([name],age) values ('benny',56)
            string sqlString = "INSERT INTO Reviews_2022 (criticizerName,email,[date],[rank],criticize,articleId) " + "VALUES ('" + review.CriticizerName + "','" + review.Email + "','" + review.Date + "','" + review.Rank + "','" + review.Criticize+ "','" + review.ArticleId +"')";
            SqlCommand command = new SqlCommand(sqlString, con);
            command.CommandTimeout = 5; // after 5 secoend it will return a timeout exception
            command.CommandType = System.Data.CommandType.Text;
            return command;
        }
    }
}